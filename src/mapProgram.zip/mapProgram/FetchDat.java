package mapProgram;
import java.util.*;

public class FetchDat {
	public static void main(String[] args) {
		
	
	LinkedHashMap p=new LinkedHashMap();
	
	p.put(1, "anil");
	p.put(2, "suniil");
	p.put(3, "vinod");
	
	ArrayList t=new ArrayList();
	t.add(100);
	t.add(200);
	t.add(300);
	
	p.put(4, t);
	
	Set keys=p.keySet();
	

	
	
	
	
	
	
	}
}
