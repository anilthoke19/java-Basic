package collectionJava;
import java.util.*;



public class SetDemo {
	
	
	public static void main(String[] args) {
		
		int a=20;
		float j=232f;
		
		
		Integer c=Integer.valueOf(a);
		a=c.intValue();
		//System.out.println(c);
		
		float h=232f;
		
	
		
		
	

		
		
		
	}

}
