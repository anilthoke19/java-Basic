package collectionJava;

public class LoginCM {
	int id;
	String pass;
	
	void setData(int id,String pass)
	{
		this.id=id;
		this.pass=pass;
	}
	void CustomerLogin()
	{
		
		
	}
	
	
	void ManagerLogin()
	{
		
	}

}
